---
description: How to run the My Beauty Passport project locally
---

# Running the Project

Follow these steps to set up and run the "My Beauty Passport" application locally.

## Prerequisites

Ensure you have **Node.js** (v18+) and **npm** installed. Alternatively, you can use **Bun**.

## Steps

1.  **Navigate to the project directory**:
    ```powershell
    cd c:\Users\jeeva\Downloads\my-beauty-passport-main
    ```

2.  **Install dependencies**:
    Using npm:
    ```powershell
    npm install
    ```
    *Note: If you encounter dependency conflicts, try `npm install --legacy-peer-deps`.*

// turbo
3.  **Start the development server**:
    Using npm:
    ```powershell
    npm run dev
    ```
    *Alternatively, using Bun*: `bun run dev`

4.  **Access the application**:
    Open your browser and navigate to the URL shown in the terminal (usually `http://localhost:5173`).

## Troubleshooting

-   **Environment Variables**: The `.env` file is already configured with Supabase credentials. Do not delete it.
-   **Port Conflict**: If port 5173 is already in use, Vite will automatically try the next available port (e.g., 5174). Check the terminal output for the correct URL.
