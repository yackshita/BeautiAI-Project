const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY;
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;

console.log("[Gemini] API key loaded:", GEMINI_API_KEY ? `${GEMINI_API_KEY.slice(0, 8)}...` : "❌ MISSING — restart dev server");

export interface SkinAnalysisResult {
  overall_score: number;
  acne_level: string;
  oil_level: string;
  hydration_level: string;
  dark_circles: string;
  elasticity: number;
  clarity: number;
  summary: string;
  treatments: string[]; // Home treatments
  salon_treatments: { name: string; description: string; benefit: string }[];
  products: { name: string; type: string; reason: string; usage: string; image_tag?: string }[];
  lifestyle_tips: string[];
  analysis_source: "Gemini 1.5 Flash" | "Local Dermal Engine";
  // Multi-mode support
  analysis_type?: "face" | "hair";
  hair_metrics?: {
    density: string;
    scalp_health: string;
    texture: string;
    breakage: string;
  };
}

/**
 * Sends the captured face image (base64 JPEG) to Gemini Vision
 * and returns a parsed skin analysis report.
 */
export async function analyzeSkincareWithGemini(
  base64ImageData: string,
  userProfile?: any,
  mode: "face" | "hair" = "face"
): Promise<SkinAnalysisResult> {
  const profileContext = userProfile ? `
USER PROFILE CONTEXT:
- Skin Type: ${userProfile.skin_type || "Unknown"}
- Hair Type: ${userProfile.hair_type || "Unknown"}
- Sleep: ${userProfile.sleep_hours || 7} hours
- Stress: ${userProfile.stress_level || "Medium"}
- Water: ${userProfile.water_intake || 2}L daily
` : "";

  const facePrompt = `You are a forensic dermatologist AI. Analyze the uploaded face image with extreme precision. 
Identify unique skin patterns, pore size, inflammation levels, and hydration markers.

${profileContext}

Avoid generic "healthy" results unless the person has perfect skin. Be honest and critical.
Your analysis MUST be consistent with the provided User Profile context above where applicable.

MANDATORY SALON TREATMENT MAPPING:
If you detect any of these issues, you MUST use the corresponding Therapy name exactly:
- Acne / Pimples → "Acne Clear Therapy"
- Dark Spots / Pigmentation → "Pigment Repair Therapy"
- Dark Circles → "Under Eye Brightening Therapy"
- Dry Skin → "Deep Hydration Therapy"
- Oily Skin → "Oil Control Therapy"
- Blackheads & Whiteheads → "Deep Pore Cleansing Therapy"
- Open Pores → "Pore Refining Therapy"
- Wrinkles / Fine Lines → "Anti-Aging Renewal Therapy"
- Dull Skin → "Skin Brightening Therapy"

IMPORTANT: Do NOT recommend a salon treatment if the skin appears healthy. Return an empty array [] in that case. 

Return ONLY a valid JSON object (no markdown) with this exact structure:
{
  "analysis_type": "face",
  "overall_score": <number 0-100>,
  "acne_level": "<Low | Mild | Moderate | Severe>",
  "oil_level": "<Low | Moderate | High>",
  "hydration_level": "<Low | Moderate | High>",
  "dark_circles": "<None | Mild | Moderate | Severe>",
  "elasticity": <number 0-100>,
  "clarity": <number 0-100>,
  "summary": "<Forensic 2-3 sentence analysis>",
  "treatments": ["<home treatment 1>", "<home treatment 2>"],
  "salon_treatments": [
    { "name": "<MANDATORY THERAPY NAME>", "description": "<detailed description>", "benefit": "<primary benefit>" }
  ],
  "products": [
    { 
      "name": "<Commercial product name>", 
      "type": "<Cleanser|Moisturizer|Serum|Sunscreen|Toner|Mask>", 
      "reason": "<why>", 
      "usage": "<how>",
      "image_tag": "<tag>"
    }
  ],
  "lifestyle_tips": ["<tip 1>", "<tip 2>"],
  "analysis_source": "Gemini 1.5 Flash"
}`;

  const hairPrompt = `You are a world-class Trichologist AI. Analyze the uploaded image (focused on hair/scalp).

${profileContext}

MANDATORY HAIR TREATMENT MAPPING:
Determine hair type and recommend these EXACT therapies:
- Wavy Hair → "Wave Control Therapy" (Premium: "Smooth Wave Enhancing Treatment")
- Curly Hair → "Curl Defining Therapy" (Premium: "Advanced Curl Definition Therapy")
- Coily/Kinky Hair → "Intense Curl Nourish Therapy" (Premium: "Deep Coil Hydration Therapy")

Return ONLY a valid JSON object (no markdown) with this exact structure:
{
  "analysis_type": "hair",
  "overall_score": <number 0-100>,
  "summary": "<Scientific 2-3 sentence analysis>",
  "hair_metrics": {
    "density": "<Low | Moderate | High>",
    "scalp_health": "<Optimal | Sensitive | Irritated>",
    "texture": "<Fine | Medium | Coarse>",
    "breakage": "<Low | Moderate | High>"
  },
  "acne_level": "None", "oil_level": "<Scalp Oil: Low | Moderate | High>", "hydration_level": "<Low | Moderate | High>", "dark_circles": "None", "elasticity": 0, "clarity": 0,
  "treatments": ["<home care tip>"],
  "salon_treatments": [
    { "name": "<MANDATORY THERAPY NAME>", "description": "<description>", "benefit": "<benefit>" }
  ],
  "products": [
    { "name": "<Product name>", "type": "<Shampoo|Conditioner|Oil|Mask>", "reason": "<why>", "usage": "<how>", "image_tag": "dropper-serum" }
  ],
  "lifestyle_tips": ["<tip 1>", "<tip 2>"],
  "analysis_source": "Gemini 1.5 Flash"
}`;

  const prompt = mode === "hair" ? hairPrompt : facePrompt;

  const response = await fetch(GEMINI_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inline_data: {
                mime_type: "image/jpeg",
                data: base64ImageData,
              },
            },
          ],
        },
      ],
      generationConfig: {
        temperature: 0.1, // Set to 0.1 for maximum consistency
        maxOutputTokens: 1024,
      },
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Gemini API error: ${response.status} — ${err}`);
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";

  // Strip any accidental markdown fences
  const cleaned = text.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();

  try {
    return JSON.parse(cleaned) as SkinAnalysisResult;
  } catch {
    throw new Error("Gemini returned invalid JSON. Raw: " + text.slice(0, 200));
  }
}
