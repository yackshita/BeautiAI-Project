import React from "react";
import { ChevronLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface MobileLayoutProps {
  children: React.ReactNode;
  title?: string;
  showBack?: boolean;
  className?: string;
  headerRight?: React.ReactNode;
}

const MobileLayout: React.FC<MobileLayoutProps> = ({ children, title, showBack = false, className = "", headerRight }) => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen max-w-md mx-auto bg-background relative overflow-hidden">
      {(showBack || title) && (
        <header className="sticky top-0 z-50 flex items-center justify-between px-4 py-3 bg-background/80 backdrop-blur-sm safe-top">
          <div className="flex items-center gap-2">
            {showBack && (
              <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-muted transition-colors">
                <ChevronLeft className="w-5 h-5 text-foreground" />
              </button>
            )}
            {title && <h1 className="text-lg font-semibold text-foreground">{title}</h1>}
          </div>
          {headerRight}
        </header>
      )}
      <main className={`${className}`}>
        {children}
      </main>
    </div>
  );
};

export default MobileLayout;
