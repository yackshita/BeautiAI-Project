import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import BottomNav from "@/components/BottomNav";
import { motion, AnimatePresence } from "framer-motion";
import { Scan, FileText, Sparkles, TrendingUp } from "lucide-react";

const Index: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [showSelection, setShowSelection] = useState(false);

  return (
    <div className="min-h-screen max-w-md mx-auto relative">
      {/* Hero */}
      <div className="gradient-hero min-h-[60vh] flex flex-col items-center justify-center px-6 pt-12 pb-8 relative overflow-hidden">
        {/* Floating orbs */}
        <div className="absolute top-20 left-10 w-32 h-32 rounded-full bg-primary/10 blur-3xl animate-float" />
        <div className="absolute bottom-20 right-10 w-40 h-40 rounded-full bg-accent/10 blur-3xl animate-float" style={{ animationDelay: "1s" }} />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: [0.2, 0.8, 0.2, 1] }}
          className="text-center relative z-10"
        >
          <div className="w-20 h-20 rounded-full gradient-primary mx-auto mb-6 flex items-center justify-center shadow-elevated animate-pulse-glow">
            <Sparkles className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="font-display text-4xl font-bold italic text-foreground tracking-tight">Glowique</h1>
          <p className="text-muted-foreground mt-2 text-sm">AI Beauty Passport</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="mt-10 w-full space-y-3 relative z-10"
        >
          <div className="space-y-3">
            <Button variant="gradient" size="xl" className="w-full" onClick={() => setShowSelection(true)}>
              <Scan className="w-5 h-5" />
              Scan Your Skin
            </Button>

            {/* Selection Modal/Overlay */}
            <AnimatePresence>
              {showSelection && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 z-[60] flex items-end justify-center p-6 bg-black/60 backdrop-blur-sm"
                  onClick={() => setShowSelection(false)}
                >
                  <motion.div 
                    initial={{ y: "100%" }}
                    animate={{ y: 0 }}
                    exit={{ y: "100%" }}
                    transition={{ type: "spring", damping: 25, stiffness: 200 }}
                    className="bg-card w-full rounded-t-[3rem] p-8 space-y-6 pb-12 shadow-elevated"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="w-12 h-1.5 bg-muted rounded-full mx-auto mb-2 opacity-30" />
                    <div className="text-center space-y-1">
                      <h3 className="text-2xl font-bold text-foreground">What's the focus today?</h3>
                      <p className="text-sm text-muted-foreground">Select an analysis mode to begin your scan</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4 pt-4">
                      <button 
                        onClick={() => navigate("/scanner", { state: { mode: "face" }})}
                        className="flex flex-col items-center gap-4 bg-primary/5 hover:bg-primary/10 p-6 rounded-[2.5rem] border border-primary/20 transition-all hover:scale-[1.02] active:scale-95 group"
                      >
                        <div className="w-16 h-16 rounded-3xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                          <Sparkles className="w-8 h-8" />
                        </div>
                        <span className="font-bold text-foreground">Face Analysis</span>
                      </button>
                      <button 
                        onClick={() => navigate("/scanner", { state: { mode: "hair" }})}
                        className="flex flex-col items-center gap-4 bg-accent/5 hover:bg-accent/10 p-6 rounded-[2.5rem] border border-accent/20 transition-all hover:scale-[1.02] active:scale-95 group"
                      >
                        <div className="w-16 h-16 rounded-3xl bg-accent/10 flex items-center justify-center text-accent group-hover:scale-110 transition-transform">
                          <TrendingUp className="w-8 h-8" />
                        </div>
                        <span className="font-bold text-foreground">Hair Analysis</span>
                      </button>
                    </div>
                    <Button variant="ghost" className="w-full text-muted-foreground" onClick={() => setShowSelection(false)}>Cancel</Button>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <Button variant="outline" size="lg" className="w-full bg-card/80" onClick={() => navigate("/passport")}>
            <FileText className="w-5 h-5" />
            Create Beauty Passport
          </Button>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-muted-foreground text-xs mt-8 text-center"
        >
          Your personalized beauty journey starts here
        </motion.p>
      </div>

      {/* Quick Actions */}
      <div className="px-6 py-6 space-y-4 pb-24">
        <h2 className="font-semibold text-foreground">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-3">
          {[
            { icon: Scan, label: "AI Scanner", desc: "Analyze your skin", path: "/scanner", color: "bg-primary/10 text-primary" },
            { icon: TrendingUp, label: "Dashboard", desc: "Track progress", path: "/dashboard", color: "bg-accent/10 text-accent" },
            { icon: FileText, label: "Passport", desc: "Beauty profile", path: "/passport", color: "bg-secondary text-secondary-foreground" },
            { icon: Sparkles, label: "Routine", desc: "Daily care plan", path: "/routine", color: "bg-primary/10 text-primary" },
          ].map((item) => (
            <motion.button
              key={item.path}
              whileTap={{ scale: 0.97 }}
              onClick={() => navigate(item.path)}
              className="bg-card rounded-2xl p-4 text-left shadow-soft border border-border hover:shadow-card transition-shadow"
            >
              <div className={`w-10 h-10 rounded-xl ${item.color} flex items-center justify-center mb-3`}>
                <item.icon className="w-5 h-5" />
              </div>
              <p className="font-medium text-sm text-foreground">{item.label}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{item.desc}</p>
            </motion.button>
          ))}
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default Index;
