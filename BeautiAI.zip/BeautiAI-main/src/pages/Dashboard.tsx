import React from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import MobileLayout from "@/components/MobileLayout";
import BottomNav from "@/components/BottomNav";
import { motion } from "framer-motion";
import { Calendar } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  const { data: scans } = useQuery({
    queryKey: ["scans", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("skin_scans")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data || [];
    },
    enabled: !!user,
  });

  const latestScan = scans?.[scans.length - 1];
  const glowScore = latestScan?.overall_score ?? 0;

  const chartData = scans?.map((s) => ({
    name: new Date(s.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    score: s.overall_score ?? 0,
  })) ?? [];

  // Days until next scan (every 3 days)
  const daysSinceLastScan = latestScan
    ? Math.floor((Date.now() - new Date(latestScan.created_at).getTime()) / (1000 * 60 * 60 * 24))
    : 999;
  const nextScanDays = Math.max(0, 3 - daysSinceLastScan);

  return (
    <MobileLayout title="Beauty Dashboard" showBack>
      <div className="px-6 py-4 pb-28 space-y-6">
        {/* Glow Score */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-card rounded-3xl p-6 border border-border shadow-card text-center"
        >
          <h2 className="font-semibold text-foreground mb-4">Glow Score</h2>
          <div className="relative w-36 h-36 mx-auto">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
              <circle cx="60" cy="60" r="54" fill="none" stroke="hsl(var(--muted))" strokeWidth="10" />
              <circle
                cx="60" cy="60" r="54" fill="none"
                stroke="url(#dashGrad)"
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={`${(glowScore / 100) * 339} 339`}
              />
              <defs>
                <linearGradient id="dashGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="hsl(120, 50%, 50%)" />
                  <stop offset="50%" stopColor="hsl(var(--primary))" />
                  <stop offset="100%" stopColor="hsl(var(--accent))" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-bold tabular-nums text-foreground">{glowScore}</span>
              <span className="text-xs text-muted-foreground">
                {glowScore >= 80 ? "Great!" : glowScore >= 60 ? "Good" : glowScore > 0 ? "Improving" : "No data"}
              </span>
            </div>
          </div>
        </motion.div>

        {/* Progress Chart */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card rounded-3xl p-6 border border-border shadow-card"
        >
          <h3 className="font-semibold text-foreground mb-4">Skin Progress</h3>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={160}>
              <LineChart data={chartData}>
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                <YAxis hide domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "12px",
                    fontSize: "12px",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={{ r: 4, fill: "hsl(var(--primary))" }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-8">
              Complete your first scan to see progress
            </p>
          )}
        </motion.div>

        {/* Next Scan */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-2xl p-4 border border-border shadow-soft flex items-center gap-4"
        >
          <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
            <Calendar className="w-6 h-6 text-accent" />
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">Next Scan in</p>
            <p className="text-2xl font-bold tabular-nums text-foreground">
              {latestScan ? `${nextScanDays} Days` : "Now!"}
            </p>
          </div>
        </motion.div>
      </div>
      <BottomNav />
    </MobileLayout>
  );
};

export default Dashboard;
