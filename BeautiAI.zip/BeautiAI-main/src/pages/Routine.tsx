import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import MobileLayout from "@/components/MobileLayout";
import BottomNav from "@/components/BottomNav";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Droplets, Sun, Moon, TrendingUp } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";

const defaultRoutines = {
  morning: [
    { step: 1, name: "Detox Cleanser", brand: "Junique", benefit: "Balanced Health" },
    { step: 2, name: "Brightening Serum", brand: "+C Vitamin", benefit: "Even Skin Fading" },
    { step: 3, name: "Lightweight Moisturizer", brand: "+A Vitamin", benefit: "SPF Care Cream" },
  ],
  night: [
    { step: 1, name: "Oil Cleanser", brand: "Elvira", benefit: "Deep Cleanse" },
    { step: 2, name: "Retinol Serum", brand: "SkinPro", benefit: "Cell Renewal" },
    { step: 3, name: "Night Repair Cream", brand: "Junique", benefit: "Overnight Recovery" },
  ],
};

const Routine: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<"morning" | "night">("morning");

  // 1. Fetch Latest Scan and Profile
  const { data: userData, isLoading } = useQuery({
    queryKey: ["routine-data", user?.id],
    queryFn: async () => {
      if (!user) return null;
      
      const [scanRes, profileRes] = await Promise.all([
        supabase.from("skin_scans").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(1).maybeSingle(),
        supabase.from("profiles").select("*").eq("user_id", user.id).maybeSingle()
      ]);

      return {
        latestScan: scanRes.data,
        profile: profileRes.data,
        allScans: (await supabase.from("skin_scans").select("overall_score, created_at").eq("user_id", user.id).order("created_at", { ascending: true }).limit(5)).data || []
      };
    },
    enabled: !!user,
  });

  // 2. Dynamic Routine Generator
  const generateRoutine = () => {
    if (!userData?.latestScan) return defaultRoutines[activeTab];

    const scan = userData.latestScan;
    const profile = userData.profile;
    const isHair = scan.scan_type === "hair";

    if (isHair) {
      return activeTab === "morning" 
        ? [
            { step: 1, name: "Scalp Stimulating Wash", brand: "Follicle+", benefit: "Wake up follicles" },
            { step: 2, name: "Light Volume Mist", brand: "AirLift", benefit: "All-day body" },
            { step: 3, name: "UV Shield Spray", brand: "GlowGuard", benefit: "Color & UV protection" },
          ]
        : [
            { step: 1, name: "Nourishing Oil", brand: "SilkEssence", benefit: "Overnight repair" },
            { step: 2, name: "Scalp Serum", brand: "DeepRoot", benefit: "Density support" },
            { step: 3, name: "Silk Wrap", brand: "SleepSoft", benefit: "Friction reduction" },
          ];
    }

    // Default Skin Routine logic
    const isOily = scan.oil_level === "High" || profile?.skin_type === "Oily";
    const needsAcneCare = scan.acne_level === "High" || scan.acne_level === "Moderate";

    if (activeTab === "morning") {
      return [
        { step: 1, name: isOily ? "Salicylic Acid Wash" : "Hydrating Cleanser", brand: isOily ? "ClearSkin" : "PureGlow", benefit: "Cleanse" },
        { step: 2, name: needsAcneCare ? "Blemish Serum" : "Vitamin C Serum", brand: "DermaLink", benefit: "Treatment" },
        { step: 3, name: "Daily SPF 50", brand: "SunShield", benefit: "Protection" },
      ];
    } else {
      return [
        { step: 1, name: "Double Cleanse Balm", brand: "MeltAway", benefit: "Purify" },
        { step: 2, name: "Night Repair Complex", brand: "AuraSkin", benefit: "Recovery" },
        { step: 3, name: profile?.skin_type === "Dry" ? "Barrier Cream" : "Light Night Gel", brand: "HydroLock", benefit: "Hydration" },
      ];
    }
  };

  const chartData = userData?.allScans?.map((s, i) => ({
    name: `Scan ${i + 1}`,
    score: s.overall_score ?? 0,
  })) ?? [];

  const routineItems = generateRoutine();

  if (isLoading) return (
    <MobileLayout title="Your Routine" showBack>
      <div className="flex items-center justify-center min-h-[60vh]"><div className="w-8 h-8 rounded-full gradient-primary animate-spin" /></div>
    </MobileLayout>
  );

  return (
    <MobileLayout title="Your Routine" showBack>
      <div className="px-6 py-4 pb-28 space-y-6">
        <div className="text-center space-y-1 -mt-2 mb-4">
          <p className="text-[10px] uppercase font-bold text-primary tracking-widest">
            {userData?.latestScan?.scan_type === "hair" ? "Personalized Hair Routine" : "Personalized Skin Routine"}
          </p>
          <h2 className="text-xl font-bold text-foreground">Targeted Daily Care</h2>
        </div>

        {/* Toggle */}
        <div className="flex bg-muted rounded-full p-1">
          <button
            onClick={() => setActiveTab("morning")}
            className={`flex-1 py-2.5 rounded-full text-sm font-medium transition-all flex items-center justify-center gap-2 ${
              activeTab === "morning"
                ? "bg-card text-foreground shadow-soft"
                : "text-muted-foreground"
            }`}
          >
            <Sun className="w-4 h-4" /> Morning
          </button>
          <button
            onClick={() => setActiveTab("night")}
            className={`flex-1 py-2.5 rounded-full text-sm font-medium transition-all flex items-center justify-center gap-2 ${
              activeTab === "night"
                ? "bg-accent text-accent-foreground shadow-soft"
                : "text-muted-foreground"
            }`}
          >
            <Moon className="w-4 h-4" /> Night
          </button>
        </div>

        {/* Routine Steps */}
        <div className="space-y-3">
          {routineItems.map((item, i) => (
            <motion.div
              key={item.name + i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-card rounded-2xl p-4 border border-border shadow-soft flex items-center gap-4"
            >
              <div className="w-10 h-10 rounded-xl gradient-card flex items-center justify-center">
                <Droplets className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-foreground">{item.name}</p>
                <p className="text-xs text-muted-foreground">{item.brand}</p>
                <div className="flex gap-2 items-center mt-1">
                  <span className="text-[10px] bg-secondary text-secondary-foreground px-2 py-0.5 rounded-full">
                    {item.benefit}
                  </span>
                </div>
              </div>
              <span className="text-xs text-muted-foreground font-semibold tabular-nums">{item.step}</span>
            </motion.div>
          ))}
        </div>

        {/* AI Progress */}
        <div className="bg-card rounded-3xl p-5 border border-border shadow-card">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-sm text-foreground">Health Trend</h3>
          </div>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={120}>
              <LineChart data={chartData}>
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                <YAxis hide domain={[0, 100]} />
                <Tooltip />
                <Line type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3, fill: "hsl(var(--primary))" }} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-xs text-muted-foreground text-center py-4">Perform a scan to build your trend chart</p>
          )}
        </div>

        <Button variant="outline" size="lg" className="w-full" onClick={() => navigate("/scanner")}>
          Refresh Routine with New Scan
        </Button>
      </div>
      <BottomNav />
    </MobileLayout>
  );
};

export default Routine;
