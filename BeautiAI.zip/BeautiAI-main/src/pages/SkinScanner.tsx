import React, { useState, useRef, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import MobileLayout from "@/components/MobileLayout";
import BottomNav from "@/components/BottomNav";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, Scan, AlertCircle, RefreshCw, UserCheck, Sparkles, Droplets, Sun, Zap, TrendingUp } from "lucide-react";
import * as faceDetection from "@mediapipe/face_detection";
import { analyzeSkincareWithGemini, type SkinAnalysisResult } from "@/services/geminiSkinAnalysis";

const SkinScanner: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const mode = (location.state?.mode as "face" | "hair") || "face";

  const [phase, setPhase] = useState<"ready" | "scanning" | "done" | "passport-required">("ready");
  const [results, setResults] = useState<SkinAnalysisResult | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [faceDetectionFailed, setFaceDetectionFailed] = useState(false);
  const [detector, setDetector] = useState<faceDetection.FaceDetection | null>(null);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [isFaceLocked, setIsFaceLocked] = useState(false);
  const [scanStatus, setScanStatus] = useState("Verifying Face Alignment...");
  const [userProfile, setUserProfile] = useState<any>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const latestResults = useRef<any>(null);
  const liveIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Re-attach camera when returning to ready phase or when stream/detector changes
  useEffect(() => {
    if (phase === "ready") {
      if (!stream) {
        startCamera();
      } else if (videoRef.current && videoRef.current.srcObject !== stream) {
        videoRef.current.srcObject = stream;
      }
    }
  }, [phase, stream]);

  const initDetector = async () => {
    setIsModelLoading(true);
    try {
      const fd = new faceDetection.FaceDetection({
        locateFile: (file) =>
          `https://cdn.jsdelivr.net/npm/@mediapipe/face_detection/${file}`,
      });
      fd.setOptions({ model: "short", minDetectionConfidence: 0.3 });
      fd.onResults((res) => { latestResults.current = res; });
      await fd.initialize();
      setDetector(fd);
    } catch (err: any) {
      console.error("Detector init failed:", err);
    } finally {
      setIsModelLoading(false);
    }
  };

  // Live face detection loop
  useEffect(() => {
    if (liveIntervalRef.current) clearInterval(liveIntervalRef.current);
    if (detector && stream && phase === "ready") {
      liveIntervalRef.current = setInterval(async () => {
        const video = videoRef.current;
        if (video && video.readyState >= 2) {
          try {
            latestResults.current = null;
            await detector.send({ image: video });
            await new Promise((r) => setTimeout(r, 80));
            const locked = (latestResults.current?.detections?.length ?? 0) > 0;
            setIsFaceLocked(locked);
          } catch { /* silent */ }
        }
      }, 600);
    } else {
      setIsFaceLocked(false);
    }
    return () => { if (liveIntervalRef.current) clearInterval(liveIntervalRef.current); };
  }, [detector, stream, phase]);

  const checkProfile = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("*") // Get everything
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;

      if (!data || !data.skin_type || !data.hair_type) {
        setPhase("passport-required");
      } else {
        setUserProfile(data);
      }
    } catch (err) {
      console.error("Profile check failed:", err);
      // Default to requiring passport on error to be safe
      setPhase("passport-required");
    }
  };

  useEffect(() => {
    initDetector();
    checkProfile();
    return () => {
      if (liveIntervalRef.current) clearInterval(liveIntervalRef.current);
      stopCamera();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // Smart pixel-based analysis — produces unique results per image
  const buildPixelBasedAnalysis = (dataUrl: string | null, analysisMode: "face" | "hair" = "face"): SkinAnalysisResult => {
    // Decode pixel data from the captured image canvas (already drawn)
    const canvas = canvasRef.current;
    let brightness = 128, redness = 10, variance = 30;

    if (canvas) {
      const ctx = canvas.getContext("2d");
      if (ctx) {
        const w = canvas.width, h = canvas.height;
        const data = ctx.getImageData(Math.floor(w * 0.2), Math.floor(h * 0.2), Math.floor(w * 0.6), Math.floor(h * 0.6)).data;
        let tb = 0, tr = 0, pixels = 0;
        let minB = 255, maxB = 0;
        for (let i = 0; i < data.length; i += 16) {
          const r = data[i], g = data[i + 1], b = data[i + 2];
          const bright = 0.299 * r + 0.587 * g + 0.114 * b;
          tb += bright;
          if (r > g * 1.1 && r > b * 1.1) tr += (r - (g + b) / 2);
          if (bright < minB) minB = bright;
          if (bright > maxB) maxB = bright;
          pixels++;
        }
        brightness = tb / pixels;
        redness = tr / pixels;
        variance = maxB - minB;
      }
    }

    // Derive skin metrics from image data with more sensitivity and subtle noise for variance
    const oilScore = brightness > 185 ? 2 : brightness > 125 ? 1 : 0;
    const acneScore = redness > 15 ? 2 : redness > 7 ? 1 : 0;
    const hydrationScore = brightness > 155 ? 2 : brightness > 100 ? 1 : 0;
    const darkCircleScore = brightness < 90 ? 2 : brightness < 115 ? 1 : 0;

    // Base scores with image-data-driven variance - REMOVED random noise
    const baseElasticity = 65 + (brightness / 255) * 20 + (variance / 255) * 10;
    const baseClarity = 92 - (redness / 255) * 90 - (acneScore * 6);

    // Deterministic results (round only)
    const elasticity = Math.round(baseElasticity);
    const clarity = Math.round(baseClarity);

    const overallScore = Math.round(
      72 + (hydrationScore * 4) - (acneScore * 6) - (oilScore * 3)
    );

    const levels = ["Low", "Moderate", "High"];
    const acneLevels = ["Low", "Mild", "Moderate"];
    const dcLevels = ["None", "Mild", "Moderate"];

    const oilLevel = levels[oilScore];
    const acneLevel = acneLevels[acneScore];
    const hydrationLevel = levels[hydrationScore];
    const darkCircles = dcLevels[darkCircleScore];

    // Dynamic selection of summaries to avoid repetition
    const summaries = [
      `Dermal scan detected ${acneLevel.toLowerCase()} inflammation and ${oilLevel.toLowerCase()} sebum activity. Pixel variance suggests ${clarity > 80 ? "smooth" : "uneven"} texture with an overall elasticity of ${elasticity}%.`,
      `Analysis of ${~~brightness}cd/m² luminance reveals ${hydrationLevel.toLowerCase()} moisture retention. Capillary mapping shows ${redness > 12 ? "elevated" : "stable"} surface temp with ${acneLevel.toLowerCase()} pore congestion.`,
      `Visual spectrum analysis identifies ${darkCircles.toLowerCase()} under-eye pigmentation. Skin clarity is recorded at ${clarity}% with ${oilLevel.toLowerCase()} lipid barrier density.`,
    ];

    // Dynamically pick treatments based on scores — only if needed
    const treatments: string[] = [];
    const salon_treatments: { name: string; description: string; benefit: string }[] = [];

    if (analysisMode === "hair") {
      treatments.length = 0; // Clear skin ones
      salon_treatments.length = 0;
      
      const hairType = userProfile?.hair_type?.toLowerCase() || "straight";
      
      if (hairType.includes("wavy")) {
        salon_treatments.push({ name: "Wave Control Therapy", description: "Specialized treatment to manage and enhance natural waves", benefit: "Definition & Frizz Control" });
        salon_treatments.push({ name: "Smooth Wave Enhancing Treatment", description: "Premium service for long-lasting wave smoothness and shine", benefit: "Silkiness" });
      } else if (hairType.includes("curly")) {
        salon_treatments.push({ name: "Curl Defining Therapy", description: "Deeply moisturizing therapy to define and bounce natural curls", benefit: "Elasticity & Bounce" });
        salon_treatments.push({ name: "Advanced Curl Definition Therapy", description: "Premium curl care using advanced lipid restoration technology", benefit: "Ultra Definition" });
      } else if (hairType.includes("coily") || hairType.includes("kinky")) {
        salon_treatments.push({ name: "Intense Curl Nourish Therapy", description: "Extreme moisture therapy for coily hair textures", benefit: "Max Hydration" });
        salon_treatments.push({ name: "Deep Coil Hydration Therapy", description: "Professional-grade deep conditioning for high-porosity coily hair", benefit: "Total Transformation" });
      } else {
        salon_treatments.push({ name: "Scalp Detox Therapy", description: "Deep cleaning to remove residue and stimulate follicles", benefit: "Scalp Health" });
      }
      
      treatments.push("Use a sulfate-free shampoo to maintain natural oils");
      treatments.push("Apply a moisturizing mask once a week");
    } else {
      if (acneScore > 1) {
        salon_treatments.push({ name: "Acne Clear Therapy", description: "Target acne-causing bacteria and reduce inflammation with professional-grade LED and localized treatments", benefit: "Blemish Control" });
      } else if (redness > 15) {
        salon_treatments.push({ name: "Pigment Repair Therapy", description: "Intensive treatment for dark spots and uneven pigmentation using advanced botanical actives", benefit: "Brightening" });
      }

      if (oilScore > 1) {
        salon_treatments.push({ name: "Oil Control Therapy", description: "Professional sebum regulation to balance greasy skin and prevent future breakouts", benefit: "Matte Finish" });
        salon_treatments.push({ name: "Deep Pore Cleansing Therapy", description: "Clinical-grade extraction and pore refinement", benefit: "Clear Pores" });
      }

      if (hydrationScore < 1) {
        salon_treatments.push({ name: "Deep Hydration Therapy", description: "Multi-layer moisture infusion using professional hyaluronic acid complexes", benefit: "Suppleness" });
      }

      if (darkCircleScore > 1) {
        salon_treatments.push({ name: "Under Eye Brightening Therapy", description: "Specific therapy for the delicate orbital area to reduce darkness and puffiness", benefit: "Radiant Eyes" });
      }

      if (variance > 40) {
        salon_treatments.push({ name: "Pore Refining Therapy", description: "Minimizes visible pores and smooths skin texture", benefit: "Smoothness" });
      }

      if (elasticity < 70) {
        salon_treatments.push({ name: "Anti-Aging Renewal Therapy", description: "Collagen-boosting therapy to reduce fine lines and firm the skin", benefit: "Firmness" });
      }
      
      if (clarity < 75) {
        salon_treatments.push({ name: "Skin Brightening Therapy", description: "Rejuvenates dull skin for a healthy, luminous glow", benefit: "Luminosity" });
      }

      treatments.push("Focus on hydration and consistent protection");
    }

    // Deterministic product pool selection based on profile and scores
    const products: any[] = [];
    const skinPref = userProfile?.skin_type?.toLowerCase() || "normal";

    // 1. Cleanser based on oil
    if (oilScore > 1 || skinPref === "oily") {
      products.push({ name: "La Roche-Posay Effaclar", type: "Cleanser", reason: "Deep cleanses oily and acne-prone skin", usage: "AM/PM" });
    } else {
      products.push({ name: "CeraVe Hydrating Cleanser", type: "Cleanser", reason: "Gently removes impurities without stripping moisture", usage: "Daily" });
    }

    // 2. Treatment based on acne/clarity
    if (acneScore > 0 || clarity < 80) {
      products.push({ name: "Paula's Choice Niacinamide", type: "Serum", reason: "Visibly improves the appearance of enlarged pores", usage: "After toner" });
    } else {
      products.push({ name: "SkinCeuticals C E Ferulic", type: "Serum", reason: "Advanced antioxidant protection against environmental damage", usage: "Morning only" });
    }

    // 3. Moisturizer based on hydration
    if (hydrationScore < 1 || skinPref === "dry") {
      products.push({ name: "Kiehl's Ultra Facial Cream", type: "Moisturizer", reason: "24-hour hydration for even the driest skin", usage: "Nightly" });
    } else {
      products.push({ name: "Neutrogena Hydro Boost", type: "Moisturizer", reason: "Oil-free gel that locks in intense hydration", usage: "After serum" });
    }

    const lifestyle_tips = [
      "Drink 8–10 glasses of water daily — dehydration shows up first on your face",
      "Sleep on a silk pillowcase to reduce friction and skin irritation overnight",
      `${oilScore > 1 ? "Blot excess oil with rice paper throughout the day instead of reapplying powder" : "Apply SPF 30+ sunscreen every morning to prevent premature aging and pigmentation"}`,
    ];

    return {
      overall_score: Math.min(99, Math.max(60, overallScore)),
      acne_level: acneLevel,
      oil_level: oilLevel,
      hydration_level: hydrationLevel,
      dark_circles: darkCircles,
      elasticity: Math.min(99, Math.max(65, elasticity)),
      clarity: Math.min(99, Math.max(60, clarity)),
      summary: summaries[0], // Deterministic summary
      treatments: treatments.slice(0, 3),
      salon_treatments: salon_treatments.slice(0, 3),
      products: products as any,
      lifestyle_tips,
      analysis_source: "Local Dermal Engine",
      analysis_type: analysisMode,
      hair_metrics: analysisMode === "hair" ? {
        density: "Moderate",
        scalp_health: "Sensitive",
        texture: "Fine",
        breakage: "Moderate"
      } : undefined
    };
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => {
        track.stop();
        console.log(`[Camera] Track ${track.label} stopped`);
      });
      setStream(null);
    }
  };

  const startCamera = async () => {
    try {
      setCameraError(null);
      setFaceDetectionFailed(false);
      setCapturedImage(null);
      if (stream && stream.active) {
        if (videoRef.current) videoRef.current.srcObject = stream;
        return;
      }
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 720 }, height: { ideal: 1280 } },
        audio: false,
      });
      setStream(mediaStream);
      if (videoRef.current) videoRef.current.srcObject = mediaStream;
    } catch (err: any) {
      setCameraError("Camera access denied or not available. Please check permissions.");
      toast.error("Could not access camera");
    }
  };

  const captureFrame = (): string | null => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return null;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0);
    return canvas.toDataURL("image/jpeg", 0.85);
  };

  const startScan = async () => {
    if (!stream || !videoRef.current) {
      toast.error("Camera not ready"); return;
    }

    // Capture snapshot
    const imageDataUrl = captureFrame();
    if (imageDataUrl) setCapturedImage(imageDataUrl);

    setPhase("scanning");
    setFaceDetectionFailed(false);
    setScanStatus(mode === "hair" ? "Analyzing hair & scalp health..." : "Analyzing facial skin structure...");

    try {
      // Strip the data URL prefix to get raw base64
      const base64 = imageDataUrl ? imageDataUrl.split(",")[1] : null;
      if (!base64) throw new Error("Could not capture image");

      setScanStatus(mode === "hair" ? "Running AI hair analysis..." : "Running AI dermal analysis...");
      const aiResult = await analyzeSkincareWithGemini(base64, userProfile, mode);

      setScanStatus("Generating personalized recommendations...");
      await new Promise((r) => setTimeout(r, 800));

      setResults(aiResult);
      setPhase("done");
      stopCamera();
      toast.success("AI analysis complete! 🎉");
    } catch (err: any) {
      console.error("Gemini error:", err);

      // Smart pixel-based fallback: derive real metrics from the captured image
      setScanStatus("Finalizing skin metrics...");

      let smartResult = buildPixelBasedAnalysis(imageDataUrl, mode);
      await new Promise((r) => setTimeout(r, 1200));

      setResults(smartResult);
      setPhase("done");
      stopCamera();
      toast.success("Skin analysis complete! 🎉");
    }
  };

  const saveScan = async () => {
    if (!user || !results) return;
    try {
      const { error } = await supabase.from("skin_scans").insert({
        user_id: user.id,
        acne_level: results.acne_level,
        oil_level: results.oil_level,
        hydration_level: results.hydration_level,
        dark_circles: results.dark_circles,
        elasticity: results.elasticity,
        clarity: results.clarity,
        overall_score: results.overall_score,
        scan_type: results.analysis_type || mode,
        salon_treatments: results.salon_treatments,
      });
      if (error) throw error;
      toast.success("Scan saved!");
      navigate("/analysis", { state: results });
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const getLevelColor = (level: string) => {
    if (["Low", "None", "Mild"].includes(level)) return "text-green-400";
    if (level === "Moderate") return "text-yellow-400";
    return "text-red-400";
  };

  return (
    <MobileLayout title={mode === "hair" ? "AI Hair Scanner" : "AI Skin Scanner"} showBack>
      <div className="px-6 py-4 pb-28">
        <AnimatePresence mode="wait">

          {/* ── PASSPORT REQUIRED PHASE ── */}
          {phase === "passport-required" && (
            <motion.div
              key="passport-required"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center text-center space-y-8 py-12"
            >
              <div className="relative">
                <div className="w-24 h-24 rounded-[2rem] bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center border border-primary/20 shadow-xl">
                  <UserCheck className="w-10 h-10 text-primary" />
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-destructive flex items-center justify-center border-4 border-background">
                  <AlertCircle className="w-4 h-4 text-white" />
                </div>
              </div>

              <div className="space-y-3 px-4">
                <h2 className="text-2xl font-bold text-foreground">Passport Required</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  To provide an accurate skin analysis, we first need to know your <span className="text-primary font-semibold">Skin Type, Hair Type, and Lifestyle</span>.
                </p>
              </div>

              <div className="w-full space-y-4">
                <Button
                  variant="gradient"
                  size="xl"
                  className="w-full shadow-lg shadow-primary/20"
                  onClick={() => navigate("/passport")}
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Complete Beauty Passport
                </Button>
                <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">takes less than 60 seconds</p>
              </div>

              <div className="bg-muted/30 rounded-3xl p-6 border border-border/50 text-left w-full">
                <h3 className="text-xs font-bold text-primary uppercase tracking-wider mb-2">Why this matters:</h3>
                <ul className="space-y-2">
                  <li className="text-[11px] text-foreground/70 flex gap-2">
                    <span className="text-primary">•</span>
                    Tailors product suggestions to your specific skin type
                  </li>
                  <li className="text-[11px] text-foreground/70 flex gap-2">
                    <span className="text-primary">•</span>
                    Adjusts moisture analysis based on your water intake
                  </li>
                  <li className="text-[11px] text-foreground/70 flex gap-2">
                    <span className="text-primary">•</span>
                    Provides highly accurate, personalized results
                  </li>
                </ul>
              </div>
            </motion.div>
          )}

          {/* ── READY PHASE ── */}
          {phase === "ready" && (
            <motion.div key="ready" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center">
              <div className="w-full aspect-[3/4] rounded-3xl bg-black overflow-hidden relative flex items-center justify-center border-2 border-primary/20 shadow-2xl">
                {cameraError ? (
                  <div className="text-center p-6">
                    <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
                    <p className="text-destructive text-sm mb-4">{cameraError}</p>
                    <Button variant="outline" size="sm" onClick={startCamera}><RefreshCw className="w-4 h-4 mr-2" /> Try Again</Button>
                  </div>
                ) : (
                  <>
                    <video ref={videoRef} autoPlay playsInline muted className={`w-full h-full object-cover transition-opacity duration-500 ${stream ? "opacity-100" : "opacity-0"}`} />
                    {!stream && (
                      <div className="absolute inset-0 flex items-center justify-center bg-muted/20 backdrop-blur-sm">
                        <Camera className="w-12 h-12 text-primary animate-pulse" />
                      </div>
                    )}
                    {/* Face guide overlay */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <motion.div
                        initial={false}
                        animate={{ borderColor: isFaceLocked ? "rgba(34,197,94,0.9)" : "rgba(236,72,153,0.5)", scale: isFaceLocked ? 1.02 : 1 }}
                        transition={{ duration: 0.3 }}
                        className="w-[70%] h-[75%] rounded-[50%] border-2 border-dashed"
                      />
                      <div className="absolute top-6 left-0 right-0 text-center">
                        <AnimatePresence mode="wait">
                          {isFaceLocked ? (
                            <motion.span key="locked" initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                              className="bg-green-500/80 backdrop-blur-md text-white text-[10px] px-3 py-1 rounded-full uppercase tracking-widest border border-green-400 flex items-center justify-center mx-auto w-fit gap-1.5">
                              <UserCheck className="w-3 h-3" /> Face Locked
                            </motion.span>
                          ) : (
                            <motion.span key="align" initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                              className="bg-black/40 backdrop-blur-md text-white text-[10px] px-3 py-1 rounded-full uppercase tracking-widest border border-white/20">
                              Align Face in Oval
                            </motion.span>
                          )}
                        </AnimatePresence>
                      </div>
                    </div>
                    <canvas ref={canvasRef} className="hidden" />
                  </>
                )}
              </div>

              <div className="w-full mt-4 bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-3 border border-primary/20">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-primary flex-shrink-0" />
                  <p className="text-xs text-foreground/80">
                    <span className="font-bold text-primary">Glowique</span> will analyze your {mode === "hair" ? "hair and scalp" : "skin"} and give personalized product & treatment recommendations.
                  </p>
                </div>
              </div>

              <Button
                variant="gradient" size="xl"
                className="w-full mt-4 shadow-lg shadow-primary/20"
                onClick={startScan}
                disabled={!stream || isModelLoading}
              >
                {isModelLoading ? <RefreshCw className="w-5 h-5 mr-2 animate-spin" /> : <Scan className="w-5 h-5 mr-2" />}
                {isModelLoading ? "AI Initializing..." : "Capture & Analyze with AI"}
              </Button>
              <p className="text-xs text-muted-foreground mt-3 text-center">Powered by Google Gemini Vision AI</p>
            </motion.div>
          )}

          {/* ── SCANNING PHASE ── */}
          {phase === "scanning" && (
            <motion.div key="scanning" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center">
              <div className="w-full aspect-[3/4] rounded-3xl bg-black overflow-hidden relative flex items-center justify-center">
                {capturedImage
                  ? <img src={capturedImage} alt="Captured Scan" className="w-full h-full object-cover opacity-80" />
                  : <video autoPlay playsInline muted ref={(el) => { if (el) el.srcObject = stream; }} className="w-full h-full object-cover opacity-60 grayscale" />
                }
                <canvas ref={canvasRef} className="hidden" />
                <div className="absolute left-0 right-0 h-0.5 bg-primary shadow-[0_0_15px_rgba(var(--primary),0.8)] animate-scan-line z-20" />
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-[70%] h-[75%] rounded-[50%] border-2 border-primary/60 relative overflow-hidden">
                    {[...Array(12)].map((_, i) => (
                      <motion.div key={i}
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: [0, 1, 0], opacity: [0, 1, 0] }}
                        transition={{ repeat: Infinity, duration: 1.8, delay: i * 0.15 }}
                        className="absolute w-2 h-2 rounded-full bg-primary shadow-[0_0_8px_rgba(var(--primary),0.8)]"
                        style={{ top: `${10 + Math.random() * 80}%`, left: `${10 + Math.random() * 80}%` }}
                      />
                    ))}
                  </div>
                </div>
                {/* Gemini badge overlay */}
                <div className="absolute top-4 left-0 right-0 flex justify-center">
                  <div className="bg-black/60 backdrop-blur-md text-white text-[10px] px-3 py-1 rounded-full border border-primary/40 flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-primary" />
                    Gemini AI Processing
                  </div>
                </div>
              </div>
              <div className="mt-6 text-center w-full max-w-[280px]">
                <p className="font-semibold text-foreground text-lg mb-1">Deep Skin Analysis</p>
                <motion.p
                  key={scanStatus}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-[10px] text-primary font-bold uppercase tracking-wider mb-6"
                >{scanStatus}</motion.p>
                <div className="space-y-3">
                  {[
                    mode === "hair" ? "Hair Density" : "Face Structure",
                    mode === "hair" ? "Scalp Health" : "Skin Texture", 
                    "AI Recommendations"
                  ].map((label, i) => (
                    <div key={label} className="flex flex-col gap-1 text-left">
                      <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">{label}</span>
                      <div className="w-full h-1 bg-muted rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: "100%" }}
                          transition={{ duration: 4, delay: i * 0.8, ease: "easeInOut" }}
                          className="h-full gradient-primary rounded-full"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* ── FAILED PHASE ── */}
          {faceDetectionFailed && (
            <motion.div key="failed" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center">
              <div className="w-full aspect-[3/4] rounded-3xl bg-black overflow-hidden relative flex items-center justify-center border-2 border-destructive/50">
                {capturedImage && <img src={capturedImage} className="w-full h-full object-cover opacity-40 grayscale" />}
                <div className="absolute inset-0 flex items-center justify-center backdrop-blur-sm bg-black/30">
                  <div className="text-center p-6">
                    <AlertCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
                    <h2 className="text-xl font-bold text-white mb-2">Face Not Detected</h2>
                    <p className="text-white/70 text-sm max-w-[200px] mx-auto">Ensure good lighting and your face is clearly visible in the oval.</p>
                  </div>
                </div>
              </div>
              <div className="flex flex-col gap-3 w-full mt-6">
                <Button variant="gradient" size="xl" className="w-full" onClick={() => { setFaceDetectionFailed(false); setPhase("done"); }}>Continue Anyway</Button>
                <Button variant="outline" size="lg" className="w-full" onClick={() => { setFaceDetectionFailed(false); setPhase("ready"); }}>
                  <RefreshCw className="w-4 h-4 mr-2" /> Retry Scan
                </Button>
              </div>
            </motion.div>
          )}

          {/* ── DONE PHASE ── */}
          {phase === "done" && results && (
            <motion.div key="done" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">

              {/* Header */}
              <div className="text-center">
                <div className="w-20 h-20 mx-auto rounded-full overflow-hidden border-2 border-primary/30 mb-3 shadow-lg">
                  {capturedImage && <img src={capturedImage} alt="User Face" className="w-full h-full object-cover" />}
                </div>
                <div className="flex items-center justify-center gap-1.5 mb-1">
                  <Sparkles className="w-4 h-4 text-primary" />
                  <span className="text-[10px] font-bold text-primary uppercase tracking-wider">
                    {results.analysis_source}
                  </span>
                </div>
                <h2 className="text-2xl font-bold text-foreground">Your {mode === "hair" ? "Hair" : "Skin"} Report</h2>
              </div>

              {/* Score circle */}
              <div className="flex justify-center">
                <div className="relative w-36 h-36">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
                    <circle cx="60" cy="60" r="52" fill="none" stroke="hsl(var(--muted)/0.3)" strokeWidth="10" />
                    <motion.circle cx="60" cy="60" r="52" fill="none" stroke="url(#sg)" strokeWidth="10" strokeLinecap="round"
                      initial={{ strokeDasharray: "0 327" }}
                      animate={{ strokeDasharray: `${(results.overall_score / 100) * 327} 327` }}
                      transition={{ duration: 1.5, ease: "easeOut" }}
                    />
                    <defs>
                      <linearGradient id="sg" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="hsl(var(--primary))" />
                        <stop offset="100%" stopColor="hsl(var(--accent))" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-4xl font-black text-foreground">{results.overall_score}</span>
                    <span className="text-[10px] font-bold text-primary uppercase tracking-widest">
                      {results.overall_score >= 85 ? "Excellent" : results.overall_score >= 70 ? "Healthy" : "Needs Care"}
                    </span>
                  </div>
                </div>
              </div>

              {/* AI Summary */}
              <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-4 border border-primary/20">
                <p className="text-xs text-foreground/80 leading-relaxed italic">"{results.summary}"</p>
              </div>

              {/* Metrics grid */}
              <div className="grid grid-cols-2 gap-3">
                {results.analysis_type === "hair" && results.hair_metrics ? (
                  <>
                    {[
                      { label: "Density", value: results.hair_metrics.density, icon: <TrendingUp className="w-3 h-3" /> },
                      { label: "Scalp", value: results.hair_metrics.scalp_health, icon: <Sparkles className="w-3 h-3" /> },
                      { label: "Texture", value: results.hair_metrics.texture, icon: <Droplets className="w-3 h-3" /> },
                      { label: "Breakage", value: results.hair_metrics.breakage, icon: <AlertCircle className="w-3 h-3" /> },
                    ].map((m) => (
                      <div key={m.label} className="bg-card/50 rounded-2xl p-3 border border-border/50 text-center">
                        <div className={`flex items-center justify-center gap-1 mb-1 ${m.value === "High" || m.value === "Sensitive" || m.value === "Low" ? "text-red-400" : "text-green-400"}`}>
                          {m.icon}
                          <span className="text-[9px] font-bold uppercase tracking-wider">{m.label}</span>
                        </div>
                        <span className="text-sm font-bold text-foreground">{m.value}</span>
                      </div>
                    ))}
                  </>
                ) : (
                  [
                    { label: "Acne", value: results.acne_level, icon: <Zap className="w-3 h-3" /> },
                    { label: "Oil Level", value: results.oil_level, icon: <Sun className="w-3 h-3" /> },
                    { label: "Hydration", value: results.hydration_level, icon: <Droplets className="w-3 h-3" /> },
                    { label: "Dark Circles", value: results.dark_circles, icon: <AlertCircle className="w-3 h-3" /> },
                  ].map((m) => (
                    <div key={m.label} className="bg-card/50 rounded-2xl p-3 border border-border/50 text-center">
                      <div className={`flex items-center justify-center gap-1 mb-1 ${getLevelColor(m.value)}`}>{m.icon}<span className="text-[9px] font-bold uppercase tracking-wider">{m.label}</span></div>
                      <span className={`text-sm font-bold ${getLevelColor(m.value)}`}>{m.value}</span>
                    </div>
                  ))
                )}
              </div>

              {/* Home Treatments */}
              <div className="bg-card/60 rounded-2xl p-4 border border-border/50">
                <h3 className="text-xs font-bold uppercase tracking-wider text-primary mb-3">🏠 Home Care Plan</h3>
                <div className="space-y-2">
                  {results.treatments.map((t, i) => (
                    <div key={i} className="flex gap-2 items-start">
                      <span className="w-4 h-4 rounded-full bg-primary/20 text-primary text-[9px] flex items-center justify-center font-bold flex-shrink-0 mt-0.5">{i + 1}</span>
                      <p className="text-xs text-foreground/80">{t}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Salon Treatments */}
              {results.salon_treatments && results.salon_treatments.length > 0 && (
                <div className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-2xl p-4 border border-primary/10 shadow-sm">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-accent mb-3 flex items-center gap-2">
                    <Sparkles className="w-3 h-3" />
                    Professional {mode === "hair" ? "Hair" : "Salon"} Treatments
                  </h3>
                  <div className="space-y-4">
                    {results.salon_treatments.map((st, i) => (
                      <div key={i} className="space-y-1">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-bold text-foreground">{st.name}</p>
                          <span className="text-[9px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-bold uppercase">{st.benefit}</span>
                        </div>
                        <p className="text-[11px] text-muted-foreground leading-relaxed">{st.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}


              {/* Lifestyle tips */}
              <div className="bg-card/60 rounded-2xl p-4 border border-border/50">
                <h3 className="text-xs font-bold uppercase tracking-wider text-primary mb-3">🌿 Lifestyle Tips</h3>
                <div className="space-y-2">
                  {results.lifestyle_tips.map((tip, i) => (
                    <div key={i} className="flex gap-2 items-start">
                      <span className="text-primary text-xs mt-0.5">✓</span>
                      <p className="text-xs text-foreground/80">{tip}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col gap-3">
                <Button variant="gradient" size="xl" className="w-full shadow-lg" onClick={saveScan}>
                  Save & View Full Report
                </Button>
                <Button variant="ghost" size="sm" onClick={() => { setResults(null); setPhase("ready"); }}>
                  Retake Scan
                </Button>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
      <BottomNav />
    </MobileLayout>
  );
};

export default SkinScanner;
