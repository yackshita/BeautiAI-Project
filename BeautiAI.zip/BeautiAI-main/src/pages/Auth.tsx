import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

const Auth: React.FC = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(false);
  const [isResetMode, setIsResetMode] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  
  const { signIn, signUp, resetPassword, updatePassword } = useAuth();
  const navigate = useNavigate();

  const handleResetPassword = () => {
    setIsResetMode(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isResetMode) {
        if (newPassword !== confirmPassword) {
          toast.error("Passwords do not match");
          return;
        }
        await updatePassword(newPassword);
        toast.success("Password updated successfully!");
        setIsResetMode(false);
      } else if (isSignUp) {
        await signUp(email, password, fullName);
        toast.success("Account created! Please check your email to verify.");
      } else {
        await signIn(email, password);
        toast.success("Welcome back!");
        navigate("/");
      }
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen max-w-md mx-auto gradient-hero flex flex-col items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-full gradient-primary mx-auto mb-4 flex items-center justify-center shadow-elevated">
            <Sparkles className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="font-display text-3xl font-bold italic text-foreground">Glowique</h1>
          <p className="text-muted-foreground text-sm mt-1">AI Beauty Passport</p>
        </div>

        <div className="bg-card rounded-3xl p-6 shadow-card">
          <h2 className="text-xl font-semibold text-center mb-6 text-foreground">
            {isResetMode ? "Reset Password" : isSignUp ? "Create Account" : "Welcome Back"}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isResetMode ? (
              <>
                <Input
                  type="password"
                  placeholder="New Password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="h-12 rounded-xl bg-muted border-0"
                  required
                  minLength={6}
                />
                <Input
                  type="password"
                  placeholder="Confirm New Password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="h-12 rounded-xl bg-muted border-0"
                  required
                  minLength={6}
                />
              </>
            ) : (
              <>
                {isSignUp && (
                  <Input
                    placeholder="Full Name"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="h-12 rounded-xl bg-muted border-0"
                  />
                )}
                <Input
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-12 rounded-xl bg-muted border-0"
                  required
                />
                <Input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12 rounded-xl bg-muted border-0"
                  required
                  minLength={6}
                />
                {!isSignUp && (
                  <div className="flex justify-end -mt-2">
                    <button
                      type="button"
                      onClick={handleResetPassword}
                      className="text-xs text-primary hover:underline font-medium"
                    >
                      Forgot Password?
                    </button>
                  </div>
                )}
              </>
            )}
            <Button type="submit" variant="gradient" size="lg" className="w-full" disabled={loading}>
              {loading ? "Loading..." : isResetMode ? "Update Password" : isSignUp ? "Sign Up" : "Sign In"}
            </Button>
            {isResetMode && (
              <Button type="button" variant="ghost" size="sm" className="w-full text-muted-foreground mt-2" onClick={() => setIsResetMode(false)}>
                Back to Login
              </Button>
            )}
          </form>

          <p className="text-center text-sm text-muted-foreground mt-4">
            {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
            <button onClick={() => setIsSignUp(!isSignUp)} className="text-primary font-medium">
              {isSignUp ? "Sign In" : "Sign Up"}
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default Auth;
