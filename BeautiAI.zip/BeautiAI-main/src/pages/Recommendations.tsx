import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import MobileLayout from "@/components/MobileLayout";
import BottomNav from "@/components/BottomNav";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Star, Droplets, Sparkles, Zap, Shield, Heart, Calendar, Video, Phone, MapPin, Home, Clock, UserCheck } from "lucide-react";
import type { SkinAnalysisResult } from "@/services/geminiSkinAnalysis";

const Recommendations: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  // Fallback to empty context if no state provided
  const scanResults = location.state as SkinAnalysisResult | null;
  const [bookingDate, setBookingDate] = useState("");
  const [bookingTime, setBookingTime] = useState("");
  const [isHomeService, setIsHomeService] = useState(false);

  const handleBook = (treatmentName: string) => {
    if (!bookingDate || !bookingTime) {
      toast.error("Please select a preferred date and time first");
      // Scroll to booking options
      document.querySelector("#booking-options")?.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    toast.success(`Booking request sent for ${treatmentName}! Type: ${isHomeService ? 'Home Service' : 'Salon Visit'} at ${bookingTime} on ${bookingDate}`);
  };
  
  // Dynamic Product Image Resolver
  const getProductImage = (p: any) => {
    // Map of specific tags to high-quality curated images
    const tagMap: Record<string, string> = {
      'foaming-cleanser': 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&q=80&w=400',
      'dropper-serum': 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=400',
      'night-cream': 'https://images.unsplash.com/photo-1621333100201-8bf88231613d?auto=format&fit=crop&q=80&w=400',
      'sunscreen-tube': 'https://images.unsplash.com/photo-1598440443997-3243c19fe382?auto=format&fit=crop&q=80&w=400',
      'clay-mask': 'https://images.unsplash.com/photo-1596755389378-c31d21fd1273?auto=format&fit=crop&q=80&w=400',
      'toner-bottle': 'https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fb4?auto=format&fit=crop&q=80&w=400'
    };

    // If AI provided a tag, use the map
    if (p.image_tag && tagMap[p.image_tag]) return tagMap[p.image_tag];

    // Fallback based on type using our pre-generated local assets
    const type = p.type.toLowerCase();
    if (type.includes('cleanser')) return '/products/cleanser.png';
    if (type.includes('serum')) return '/products/serum.png';
    if (type.includes('moisturizer') || type.includes('cream')) return '/products/moisturizer.png';
    if (type.includes('sunscreen')) return '/products/sunscreen.png';
    if (type.includes('toner')) return '/products/toner.png';
    if (type.includes('mask')) return '/products/mask.png';

    return '/products/serum.png'; // Ultimate fallback
  };

  // Header dynamic icon based on score
  const getScoreIcon = () => {
    if (!scanResults) return <Sparkles className="w-5 h-5 text-primary" />;
    if (scanResults.overall_score >= 85) return <Heart className="w-5 h-5 text-pink-500" />;
    if (scanResults.overall_score >= 70) return <Shield className="w-5 h-5 text-green-500" />;
    return <Zap className="w-5 h-5 text-yellow-500" />;
  };

  return (
    <MobileLayout title="Recommended for You" showBack>
      <div className="px-6 py-4 pb-28 space-y-8">
        
        {/* Header Section */}
        <div className="text-center space-y-1">
          <div className="flex justify-center mb-2">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
              {getScoreIcon()}
            </div>
          </div>
          <h1 className="text-xl font-bold text-foreground">Personalized Selection</h1>
          <div className="flex justify-center mt-1">
            <div className="bg-primary/10 px-2 py-0.5 rounded-full flex items-center gap-1 border border-primary/20">
              <Sparkles className="w-2.5 h-2.5 text-primary" />
              <span className="text-[8px] font-bold text-primary uppercase tracking-tighter">
                {scanResults?.analysis_source || "AI Scan"}
              </span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground pt-1">Based on your recent AI {scanResults?.analysis_type === "hair" ? "Hair" : "Skin"} Analysis</p>
        </div>

        {/* specialist consultation section */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-3xl p-5 border border-primary/20 shadow-sm relative overflow-hidden">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-foreground">Need more help?</h3>
              <p className="text-[10px] text-muted-foreground">Consult our {scanResults?.analysis_type === "hair" ? "Hair" : "Skin"} Specialists</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 relative z-10">
            <Button variant="outline" size="sm" className="bg-background/50 border-primary/20 gap-2 h-10" onClick={() => toast.success("Starting Video Call...")}>
              <Video className="w-4 h-4 text-primary" />
              Video Call
            </Button>
            <Button variant="outline" size="sm" className="bg-background/50 border-primary/20 gap-2 h-10" onClick={() => toast.success("Starting Audio Call...")}>
              <Phone className="w-4 h-4 text-primary" />
              Audio Call
            </Button>
          </div>
          <div className="absolute -bottom-6 -right-6 opacity-10">
            <UserCheck className="w-24 h-24 text-primary" />
          </div>
        </motion.div>

        {/* Booking Options Section */}
        <motion.div id="booking-options" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-3xl p-5 border border-border shadow-soft space-y-4">
          <div className="flex items-center gap-2 mb-1">
            <Calendar className="w-4 h-4 text-primary" />
            <h3 className="font-bold text-sm text-foreground">Booking Preferences</h3>
          </div>
          
          <div className="space-y-3">
            <div className="flex bg-muted rounded-2xl p-1">
              <button
                onClick={() => setIsHomeService(false)}
                className={`flex-1 py-2 rounded-xl text-[10px] font-bold transition-all flex items-center justify-center gap-2 ${!isHomeService ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}
              >
                <MapPin className="w-3 h-3" /> Visit Salon
              </button>
              <button
                onClick={() => setIsHomeService(true)}
                className={`flex-1 py-2 rounded-xl text-[10px] font-bold transition-all flex items-center justify-center gap-2 ${isHomeService ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}
              >
                <Home className="w-3 h-3" /> Home Service
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground ml-1 uppercase">Date</label>
                <div className="relative">
                  <input 
                    type="date" 
                    value={bookingDate}
                    onChange={(e) => setBookingDate(e.target.value)}
                    className="w-full bg-muted border-none rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-primary outline-none"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-muted-foreground ml-1 uppercase">Time</label>
                <div className="relative">
                  <input 
                    type="time" 
                    value={bookingTime}
                    onChange={(e) => setBookingTime(e.target.value)}
                    className="w-full bg-muted border-none rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-primary outline-none"
                  />
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Salon Treatments */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-foreground flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              Salon Treatments
            </h2>
            <button className="text-[10px] text-primary font-bold uppercase tracking-wider">Explore More</button>
          </div>
          <div className="space-y-4">
            {(scanResults?.salon_treatments || []).map((t, i) => (
              <motion.div
                key={t.name}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-card rounded-3xl p-5 border border-border/50 shadow-soft relative overflow-hidden group"
              >
                <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                  <Star className="w-12 h-12 text-primary" />
                </div>
                <div className="flex items-start justify-between relative z-10">
                  <div className="flex-1 pr-4">
                    <h3 className="font-bold text-base text-foreground mb-1 leading-tight">{t.name}</h3>
                    <p className="text-xs text-muted-foreground leading-relaxed mb-3">{t.description}</p>
                    <div className="flex items-center gap-1.5 bg-primary/5 w-fit px-2 py-1 rounded-lg">
                      <Zap className="w-3 h-3 text-primary" />
                      <span className="text-[10px] font-bold text-primary uppercase tracking-tight">{t.benefit}</span>
                    </div>
                  </div>
                  <Button variant="pill-active" size="sm" className="shadow-md" onClick={() => handleBook(t.name)}>Book</Button>
                </div>
              </motion.div>
            ))}
            {!scanResults?.salon_treatments && (
              <p className="text-xs text-muted-foreground text-center py-4 bg-muted/20 rounded-2xl border border-dashed border-border/50">
                Perform a skin scan to get salon recommendations
              </p>
            )}
          </div>
        </motion.div>


        <Button 
          variant="gradient" 
          size="xl" 
          className="w-full shadow-lg shadow-primary/20" 
          onClick={() => toast.info("Booking system coming soon! Visit our salon to book.")}
        >
          <Calendar className="w-5 h-5 mr-1" />
          Book an Appointment
        </Button>
      </div>
      <BottomNav />
    </MobileLayout>
  );
};

export default Recommendations;
