import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import MobileLayout from "@/components/MobileLayout";
import BottomNav from "@/components/BottomNav";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { motion } from "framer-motion";

const skinTypes = ["Oily", "Dry", "Combination", "Normal"] as const;
const hairTypes = ["Straight", "Wavy", "Curly", "Coily"] as const;
const stressLevels = ["Low", "Medium", "High"] as const;

const BeautyPassport: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [skinType, setSkinType] = useState<string>("");
  const [hairType, setHairType] = useState<string>("");
  const [sleepHours, setSleepHours] = useState(7);
  const [stressLevel, setStressLevel] = useState<string>("");
  const [waterIntake, setWaterIntake] = useState(2);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      if (!user) return;
      try {
        const { data, error } = await supabase
          .from("profiles")
          .select("*")
          .eq("user_id", user.id)
          .maybeSingle();

        if (error) throw error;
        if (data) {
          const capitalize = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
          if (data.skin_type) setSkinType(capitalize(data.skin_type));
          if (data.hair_type) setHairType(capitalize(data.hair_type));
          if (data.sleep_hours) setSleepHours(data.sleep_hours);
          if (data.stress_level) setStressLevel(capitalize(data.stress_level));
          if (data.water_intake) setWaterIntake(data.water_intake);
        }
      } catch (err: any) {
        console.error("Error fetching profile:", err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [user]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      const { error } = await supabase.from("profiles").upsert({
        user_id: user.id,
        skin_type: skinType.toLowerCase(),
        hair_type: hairType.toLowerCase(),
        sleep_hours: sleepHours,
        stress_level: stressLevel.toLowerCase(),
        water_intake: waterIntake,
        updated_at: new Date().toISOString(),
      }, {
        onConflict: 'user_id'
      });

      if (error) throw error;
      toast.success("Beauty Passport saved!");
      navigate("/dashboard");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <MobileLayout title="Create Your Beauty Passport" showBack>
      <div className="px-6 py-4 pb-28 space-y-6">
        {/* Skin Type */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <label className="text-xs uppercase tracking-widest text-muted-foreground font-semibold">Skin Type</label>
          <div className="flex flex-wrap gap-2 mt-3">
            {skinTypes.map((t) => (
              <Button
                key={t}
                variant={skinType === t ? "pill-active" : "pill"}
                size="sm"
                onClick={() => setSkinType(t)}
              >
                {t}
              </Button>
            ))}
          </div>
        </motion.div>

        {/* Hair Type */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <label className="text-xs uppercase tracking-widest text-muted-foreground font-semibold">Hair Type</label>
          <div className="flex flex-wrap gap-2 mt-3">
            {hairTypes.map((t) => (
              <Button
                key={t}
                variant={hairType === t ? "pill-active" : "pill"}
                size="sm"
                onClick={() => setHairType(t)}
              >
                {t}
              </Button>
            ))}
          </div>
        </motion.div>

        {/* Lifestyle */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <label className="text-xs uppercase tracking-widest text-muted-foreground font-semibold">Lifestyle</label>
          
          <div className="mt-3 space-y-4">
            <div className="flex items-center justify-between bg-card rounded-2xl p-4 border border-border">
              <span className="text-sm text-foreground">Sleep hours</span>
              <div className="flex items-center gap-2">
                <button onClick={() => setSleepHours(Math.max(4, sleepHours - 1))} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-foreground">-</button>
                <span className="text-lg font-semibold tabular-nums w-8 text-center">{sleepHours}</span>
                <button onClick={() => setSleepHours(Math.min(12, sleepHours + 1))} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-foreground">+</button>
                <span className="text-xs text-muted-foreground">hrs</span>
              </div>
            </div>

            <div className="bg-card rounded-2xl p-4 border border-border">
              <span className="text-sm text-foreground mb-3 block">Stress Level</span>
              <div className="flex gap-2">
                {stressLevels.map((l) => (
                  <Button
                    key={l}
                    variant={stressLevel === l ? "pill-active" : "pill"}
                    size="sm"
                    onClick={() => setStressLevel(l)}
                    className="flex-1"
                  >
                    {l}
                  </Button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between bg-card rounded-2xl p-4 border border-border">
              <span className="text-sm text-foreground">Water Intake</span>
              <div className="flex items-center gap-2">
                <button onClick={() => setWaterIntake(Math.max(0.5, waterIntake - 0.5))} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-foreground">-</button>
                <span className="text-lg font-semibold tabular-nums w-8 text-center">{waterIntake}</span>
                <button onClick={() => setWaterIntake(Math.min(5, waterIntake + 0.5))} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-foreground">+</button>
                <span className="text-xs text-muted-foreground">L daily</span>
              </div>
            </div>
          </div>
        </motion.div>

        <Button variant="gradient" size="lg" className="w-full mt-6" onClick={handleSave} disabled={saving || loading}>
          {loading ? "Loading..." : saving ? "Saving..." : "Save Profile"}
        </Button>
      </div>
      <BottomNav />
    </MobileLayout>
  );
};

export default BeautyPassport;
