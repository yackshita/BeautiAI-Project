package com.beautiai.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
