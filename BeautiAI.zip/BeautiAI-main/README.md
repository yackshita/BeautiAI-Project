# My Beauty Passport

A personalized beauty and wellness assistant that uses AI to provide tailored recommendations for skincare, haircare, and overall well-being.

## Features

- **Personalized Profile**: Create a beauty passport with your skin type, hair type, sleep patterns, and stress levels.
- **AI-Powered Recommendations**: Get intelligent suggestions for products and routines based on your profile.
- **Progress Tracking**: Monitor your skin health and wellness journey over time.
- **Community Features**: Connect with others and share your experiences.

## Tech Stack

- **Frontend**: React, TypeScript, Vite
- **Styling**: Tailwind CSS, Shadcn UI
- **AI Integration**: Google Gemini API
- **Backend**: Supabase (Auth, Database)
- **Deployment**: Netlify

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn
- Supabase account
- Google AI Studio API key

### Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd my-beauty-passport
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up environment variables:
   Create a `.env` file in the root directory with the following variables:
   ```env
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   VITE_GOOGLE_AI_API_KEY=your_google_ai_api_key
   ```

4. Run the development server:
   ```bash
   npm run dev
   ```

5. Open your browser and navigate to `http://localhost:5173`.

### Build for Production

```bash
npm run build
```

## Deployment

This project is configured for deployment to Netlify.

1. Push your changes to GitHub.
2. Import the repository into Netlify.
3. Netlify will automatically build and deploy your site.

## Project Structure

```
src/
├── components/        # Reusable UI components
├── contexts/          # React Context providers (AuthContext)
├── pages/             # Page components
├── services/          # API integration services
├── utils/             # Utility functions
└── App.tsx            # Main application component
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
