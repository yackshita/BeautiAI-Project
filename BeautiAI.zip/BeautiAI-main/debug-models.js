
const API_KEY = "AIzaSyAu5pEV6wcHJmQhXf_EbEi_tperuOc9AM4";
const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${API_KEY}`;
const fs = require('fs');

async function checkModels() {
  try {
    const response = await fetch(url);
    const data = await response.json();
    console.log("--- GOOGLE AI MODELS AVAILABLE ---");
    if (data.models) {
      const list = data.models.map(m => m.name).join('\n');
      fs.writeFileSync('models.txt', list);
      console.log("Done. Check models.txt");
    } else {
      fs.writeFileSync('models.txt', "ERROR: " + JSON.stringify(data));
      console.log("Done with error. Check models.txt");
    }
  } catch (err) {
    console.error("Fetch failed:", err);
    fs.writeFileSync('models.txt', "FATAL ERROR: " + err.message);
  }
}

checkModels();
