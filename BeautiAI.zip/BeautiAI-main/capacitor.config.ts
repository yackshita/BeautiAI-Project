import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.beautiai.app',
  appName: 'Glowique',
  webDir: 'dist'
};

export default config;
